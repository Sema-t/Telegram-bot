import asyncpg
from fuzzywuzzy import fuzz

from config import DB_NAME, DB_USER, DB_PASSWORD, DB_HOST, DB_PORT


async def connect():
    return await asyncpg.connect(
        database=DB_NAME, user=DB_USER, password=DB_PASSWORD, host=DB_HOST, port=DB_PORT
    )


async def save_user(telegram_id):
    conn = await connect()
    async with conn.transaction():
        user_exists = await conn.fetchval("SELECT EXISTS(SELECT 1 FROM users WHERE telegram_id=$1);", telegram_id)
        if not user_exists:
            await conn.execute("INSERT INTO users (telegram_id) VALUES ($1);", telegram_id)
    await conn.close()


async def save_message(telegram_id, message_text):
    conn = await connect()
    async with conn.transaction():
        user_exists = await conn.fetchval("SELECT EXISTS(SELECT 1 FROM users WHERE telegram_id=$1);", telegram_id)
        if not user_exists:
            await conn.execute("INSERT INTO users (telegram_id) VALUES ($1);", telegram_id)
        await conn.execute("""
            INSERT INTO messages (user_id, message_text)
            VALUES ($1, $2);
        """, telegram_id, message_text)
    await conn.close()


async def get_answer(question_text):
    conn = await connect()
    questions = await conn.fetch("SELECT question, answer FROM questions")
    await conn.close()

    best_match = None
    highest_ratio = 0

    for record in questions:
        question, answer = record["question"], record["answer"]
        ratio = fuzz.ratio(question_text.lower(), question.lower())

        if ratio > highest_ratio:
            highest_ratio = ratio
            best_match = answer

    if highest_ratio > 60:
        return best_match
    else:
        return "Извините, ответа на ваш вопрос нет в базе."
