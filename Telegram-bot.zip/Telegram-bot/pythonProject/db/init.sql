-- Создание таблицы пользователей
CREATE TABLE IF NOT EXISTS users (
    user_id SERIAL PRIMARY KEY,
    telegram_id BIGINT UNIQUE NOT NULL,
    first_message TIMESTAMP DEFAULT NOW()
);

-- Создание таблицы сообщений
CREATE TABLE IF NOT EXISTS messages (
    message_id SERIAL PRIMARY KEY,
    user_id BIGINT REFERENCES users(telegram_id),
    message_text TEXT NOT NULL,
    message_date TIMESTAMP DEFAULT NOW()
);

-- Создание таблицы вопросов и ответов
CREATE TABLE IF NOT EXISTS questions (
    question_id SERIAL PRIMARY KEY,
    question TEXT UNIQUE NOT NULL,
    answer TEXT NOT NULL
);

-- Вставка начальных данных в таблицу вопросов и ответов
INSERT INTO questions (question, answer) VALUES
    ('Что такое SQL?', 'SQL — это язык для управления и обработки данных в реляционных базах данных.'),
    ('Какой командой создается таблица в SQL?', 'Таблица создается командой CREATE TABLE.'),
    ('Что такое Docker?', 'Docker — это платформа для контейнеризации приложений, которая позволяет создавать и управлять контейнерами.'),
    ('Как создать виртуальное окружение в Python?', 'Виртуальное окружение создается командой python -m venv <имя_окружения>.'),
    ('Что такое PostgreSQL?', 'PostgreSQL — это объектно-реляционная система управления базами данных с открытым исходным кодом.')
ON CONFLICT DO NOTHING;