import nest_asyncio
import asyncio
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters
from db.dp import save_user, save_message, get_answer
from config import API_KEY

nest_asyncio.apply()


async def start(update: Update, context):
    user = update.message.from_user
    await save_user(user.id)
    await update.message.reply_text("Привет! Я чат-бот по базе знаний. Задай мне вопрос!")


async def handle_message(update: Update, context):
    user = update.message.from_user
    text = update.message.text
    await save_message(user.id, text)

    answer = await get_answer(text)
    await update.message.reply_text(answer)


async def main():
    application = Application.builder().token(API_KEY).build()
    application.add_handler(CommandHandler("start", start))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    print("Бот запущен и готов к работе!")
    await application.run_polling()


if __name__ == "__main__":
    asyncio.run(main())
