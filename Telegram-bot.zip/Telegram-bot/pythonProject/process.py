from db.dp import get_answer


async def process_message(question_text):
    """
    Функция обработки сообщения.
    Сейчас выполняет только поиск ответа на вопрос с использованием нечеткого поиска.

    :param question_text: Вопрос пользователя
    :return: Ответ на вопрос или сообщение об отсутствии ответа
    """
    answer = await get_answer(question_text)
    return answer